RakennusDoc setup

1) GitHub Pages
- Upload index.html, sw.js and manifest.json to the root of the repository.
- The main file must be named exactly index.html.

2) Firebase Authentication
- Firebase Console > Authentication > Sign-in method
- Enable Email/Password
- Firebase Console > Authentication > Users
- Add user: CEO email + password

3) Firestore Rules
- Firebase Console > Firestore Database > Rules
- Paste firestore.rules
- Publish

4) After upload
- Open the site and do hard refresh:
  Mac: Cmd + Shift + R
  Windows: Ctrl + Shift + R

5) Notes
- All data is stored in Firebase Firestore.
- Images/documents are uploaded to Cloudinary.
- For commercial use, later tighten rules by companyId and roles.
